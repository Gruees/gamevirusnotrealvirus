var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["54cf3656-85ba-4c05-9d9c-dca2cfc5a239","a97ad571-8812-4b0c-a5af-b1f56f40fa83"],"propsByKey":{"54cf3656-85ba-4c05-9d9c-dca2cfc5a239":{"name":"play","sourceUrl":null,"frameSize":{"x":396,"y":392},"frameCount":1,"looping":true,"frameDelay":12,"version":"n7t1ap5soj6vatKyUdaDy6AOIEFUjm1X","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":392},"rootRelativePath":"assets/54cf3656-85ba-4c05-9d9c-dca2cfc5a239.png"},"a97ad571-8812-4b0c-a5af-b1f56f40fa83":{"name":"controller (codename) prank","sourceUrl":null,"frameSize":{"x":98,"y":63},"frameCount":1,"looping":true,"frameDelay":12,"version":"rxMMi30vGJdkmWOiJ.31biUUzu0Af9T9","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":98,"y":63},"rootRelativePath":"assets/a97ad571-8812-4b0c-a5af-b1f56f40fa83.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

text("press a ;)", 50, 50);
showMobileControls(true, true, true, true);
var play = createSprite(345, 345);
play.setAnimation("play");
play.height = -100;
play.width = -100;
function draw() {
  if (keyWentDown("a")) {
    playSound("assets/default.mp3", true);
    text("Press (space) to stop", 0, 15);
  }
  if (keyWentDown("space")) {
    playSpeech("Thanks for the 500000 Dolars... we will give you milk in notime", "male", "English");
    text("Oops sorry 0: try ummm  HOLD(z) NOW TO MAKE IT STOP", 0, 200);
  }
  if (keyDown("z")) {
    playSound("assets/default.mp3", true);
    text("GET THE IPHONE 20 NOW!!", 50, 200);
    text("FREE CAR HERE", 30, 100);
    text("REMOVE ANTIVIRUS ON YOURE PC NOW FREE FUN", 200, 15);
    text("yvfuvscyugdsyvgsdyvgysgvhdsvgshd", 300, 20);
    text("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE", 100, 40);
  }
  playSpeech("get it now free cars", "male", "English");
}
drawSprites();

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
